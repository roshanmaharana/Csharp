﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace collections_exec.collections_exec
{
    class ListRemove
    {
        public static void Main()
        {
            List<int> Sequence = new List<int>();
            Console.WriteLine("Enter Sequence of numbers");
            string i = Console.ReadLine();

            while (i != "")
            {

                int number = int.Parse(i);
                Sequence.Add(number);
                i = Console.ReadLine();
            }

            Dictionary<int, int> dic = new Dictionary<int, int>();

            foreach (var value in Sequence)
            {
                dic.TryGetValue(value, out int count);
                dic[value] = count + 1;
            }

            foreach (var pair in dic)
                Console.WriteLine($"{pair.Key} -> {pair.Value}");

        }
    }
}
