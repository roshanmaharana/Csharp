﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exec_csharp
{
    class AgeException : Exception
    {
        public AgeException(string msg) : base(msg)
        {

        }
    }

    class OutputAgeExceptions
    {
        static void Main(string[] args)
        {
            try
            {
                Console.WriteLine("Enter Age of a person?");
                int age = int.Parse(Console.ReadLine());


                if (age < 0 || age > 150)
                    throw new AgeException("Age is invalid. It has to be within range of 0-150..!!");
                else
                    Console.WriteLine("Age is Valid");
            }
            catch (AgeException ex)
            {
                Console.WriteLine(ex.Message);
            }
            catch (FormatException ex)
            {
                Console.WriteLine("You have entered a wrong format. Enter a integer...");
            }

            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);
            }


        }
    }
}
