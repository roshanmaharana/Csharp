﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace exec_csharp
{
    class GradeEmployee
    {
        public int empid { get; set; }
        public string empname { get; set; }
        string address;
        string pincode;
        string phone;
        double gross_sal;
        double pf;

        public GradeEmployee(int empid, string empname, string address, string pincode, string phone, double gross_sal, double pf)
        {
            this.empid = empid;
            this.empname = empname;
            this.address = address;
            this.pincode = pincode;
            this.phone = phone;
            this.gross_sal = gross_sal;
            this.pf = pf;
        }

        double netsal()
        {
            return gross_sal - pf;
        }

        string grade()
        {
            if (netsal() > 10000)
                return " Grade - 'A' ";
            else if (netsal() > 5000)
                return " Grade - 'B' ";
            else
                return " Grade - 'C' ";
        }

        public override string ToString()
        {
            return $@"{empname}({empid}) from {address}, {pincode} is a {grade()} employee. 
                      Contact Number - {phone}";
        }

    }

    class OuputGradeEmployee
    {
        static void Main()
        {
            GradeEmployee g = new GradeEmployee(20256, "Vignesh", "Chettinad, Tamilnadu", "630107", "9487718651", 11000, 500);
            Console.WriteLine(g.ToString());
        }
    }
}
